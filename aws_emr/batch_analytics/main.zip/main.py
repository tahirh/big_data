def add(event, context):
    return event['a'] + event['b']